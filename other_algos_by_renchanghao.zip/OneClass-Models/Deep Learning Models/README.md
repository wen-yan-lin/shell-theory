## Introduction
This repo contains experiment codes for the following deep learning algorithms for one-class learning:  
1. Deep Anomaly Detection using Geometric Transformation. [[paper]](https://papers.nips.cc/paper/2018/file/5e62d03aec0d17facfc5355dd90d441c-Paper.pdf)
2. CAE + OC-SVM
3. DAGMM
4. DSEBM
5. AD-GAN

Most of implementations are adopted from [here](https://github.com/izikgo/AnomalyDetectionTransformations).

## Requirements
* Python 3.5+
* Keras 2.2.0
* Tensorflow 1.8.0
* sklearn 0.19.1

## Usage (Running Experiments on A New Dataset)
- To run experiments on a new dataset, you will need to implement a load_data function inside ***utils.py*** file, in the follwing format.  
   ```python
  def load_dataset():
      # Load data into variables X_train, X_test, y_train, y_test
      return (X_train, y_train), (X_test, y_test) 
   ```
   All the models take raw image data (2D numpy array) as input data.  
   Note that the experiments are carried out in an one-vs-rest fashion. When loading a dataset, load it in multi-class format, i.e. multiclass labels. Then, the one-class experiments will be carried out for every class vs the rest classes in the dataset.   
   Remember to add a new entry inside the **get_class_name_from_index()** function, in the format a key-value pair. Key is the new dataset name, value is a tuple of ordered class names of the dataset.
- Configure the **run_experiment()** function inside ***experiments.py*** to configure the models you want to use.
- Fill in the **experiments_list** variable inside **main** of ***experiments.py*** to select the datasets you want to run experiments on, in the format of a tuple - (**load_fn**: the function to load the dataset, **name**: dataset name, **num_classes**: number of classes inside dataset.)
- Start execution of experiments with:
  ```bash
  python experiments.py
  ```
- Results will be saved at directory specified by **RESULTS_DIR** variable.