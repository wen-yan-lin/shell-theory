## Introduction
This repo contains code for one-class learning using OneClass-SVM (OC-SVM) and Mahalanobis distance. 

## Usage
Both methods take feature vectors as input data.  
A sample of how to run the code is included in the jupyter notebook.