import numpy as np
from sklearn.metrics import roc_auc_score
from sklearn.svm import OneClassSVM
from sklearn.covariance import EmpiricalCovariance
from sklearn.metrics import average_precision_score, precision_score, accuracy_score
from sklearn.svm import SVC, LinearSVC
import time

def print_latex(scores):
    for i in range(scores.shape[0]):
        print("& %.3f" % (scores[i]), end=' ')
    print("& %.3f" % (np.mean(scores)), end=" \\\\")

def renormalize(data, mean):
    return unit_norm(data - mean)

def unit_norm(data):
    return data / np.linalg.norm(data, axis=1, keepdims=True)

def split_trts(all_feats, labels, n_train, num_classes):
    feats_train = []
    feats_test = []
    labels_train = []
    labels_test = []
    for i in range(num_classes):
        c_feats = all_feats[labels==i]
        c_labels = labels[labels==i]
        feats_train.append(c_feats[:n_train, :])
        feats_test.append(c_feats[n_train:, :])
        labels_train.append(c_labels[:n_train])
        labels_test.append(c_labels[n_train:])
    return np.vstack(feats_train), np.vstack(feats_test), np.hstack(labels_train), np.hstack(labels_test)

def run_onevsall_ocsvm_test(feats_tr, feats_ts, y_tr, y_ts, num_classes):
    all_auroc = []
    all_auprc = []
    for i in range(num_classes):
        curr_feats_tr = feats_tr[y_tr==i]
        ocsvm = OneClassSVM(gamma='auto').fit(curr_feats_tr)
        curr_scores = ocsvm.score_samples(feats_ts)
        curr_gt = np.zeros(y_ts.shape[0])
        curr_gt[y_ts==i] = 1
        auroc = roc_auc_score(curr_gt.astype(int), curr_scores)
        auprc = average_precision_score(curr_gt.astype(int), curr_scores)
        all_auroc.append(auroc)
        all_auprc.append(auprc)
        print("- %d: %.3f - %.3f" % (i, auroc, auprc))
    return np.asarray(all_auroc), np.asarray(all_auprc)


def run_onevsall_mahalanobis_test(feats_tr, feats_ts, y_tr, y_ts, num_classes):
    all_auroc = []
    all_auprc = []
    for i in range(num_classes):
        curr_feats_tr = feats_tr[y_tr==i].copy()
        curr_mean = np.mean(curr_feats_tr, axis=0)
        curr_feats_tr = curr_feats_tr - curr_mean
        group_lasso = EmpiricalCovariance(assume_centered=False).fit(curr_feats_tr)
        curr_precision = group_lasso.precision_
        
        curr_feats_ts = feats_ts.copy() - curr_mean
        curr_scores = -0.5 * np.matmul(np.matmul(curr_feats_ts, curr_precision), curr_feats_ts.T).diagonal()
        curr_gt = np.zeros(y_ts.shape[0])
        curr_gt[y_ts==i] = 1
        auroc = roc_auc_score(curr_gt.astype(int), curr_scores)
        auprc = average_precision_score(curr_gt.astype(int), curr_scores)
        all_auroc.append(auroc)
        all_auprc.append(auprc)
        print("- %d: %.3f - %.3f" % (i, auroc, auprc))
    return np.asarray(all_auroc), np.asarray(all_auprc)


def get_means(feats, gt):
    num_class = int(np.max(gt)+1)
    means = np.zeros([num_class, feats.shape[1]])
    for i in range(num_class):
        means[i] = np.mean(feats[gt==i], axis=0)
    return means

def sorted_ancestors_means(means, target):
    distances = np.zeros(means.shape[0])
    for i in range(means.shape[0]):
        distances[i] = np.linalg.norm(means[i] - means[target])
    sorted_inds = np.argsort(distances)
    return means[sorted_inds]


def stacked_ocsvm_fit(feats_train, target, all_means):
    ancestors = sorted_ancestors_means(all_means, target)
    
    stacked_model = []
    
    curr_feats = unit_norm(feats_train)
    curr_model = OneClassSVM(gamma='auto').fit(curr_feats)
    stacked_model.append({'mean': np.zeros(feats_train.shape[1]), 'model': curr_model})
    
    for l in range(2, ancestors.shape[0]+1):
        curr_mean = np.mean(ancestors[:l, :], axis=0)
        curr_feats = renormalize(feats_train, curr_mean)
        curr_model = OneClassSVM(gamma='auto').fit(curr_feats)
        stacked_model.append({'mean': curr_mean, 'model': curr_model})
    return stacked_model

def stacked_ocsvm_score_samples(stacked_model, feats_test):
    stacked_scores = np.zeros([feats_test.shape[0], len(stacked_model)])
    # print("Length of Stacked model: %d" % (len(stacked_model)))
    i = 0
    for model in stacked_model:
        curr_mean = model['mean']
        curr_ocsvm = model['model']
        curr_feats = renormalize(feats_test, curr_mean)
        curr_scores = curr_ocsvm.score_samples(curr_feats)
        stacked_scores[:, i] = curr_scores
        i += 1
    return stacked_scores

def stacked_mahalanobis_fit(feats_train, target, all_means):
    ancestors = sorted_ancestors_means(all_means, target)
    
    stacked_model = []
    
    curr_feats = unit_norm(feats_train)
    curr_center = np.mean(curr_feats, axis=0)
    group_lasso = EmpiricalCovariance(assume_centered=False).fit(curr_feats - curr_center)
    curr_precision = group_lasso.precision_
    stacked_model.append({'mean': np.zeros(feats_train.shape[1]), 'center': curr_center, 'precision': curr_precision})
    
    for l in range(2, ancestors.shape[0]+1):
        curr_mean = np.mean(ancestors[:l, :], axis=0)
        curr_feats = renormalize(feats_train, curr_mean)
        curr_center = np.mean(curr_feats, axis=0)
        group_lasso = EmpiricalCovariance(assume_centered=False).fit(curr_feats - curr_center)
        curr_precision = group_lasso.precision_
        stacked_model.append({'mean': curr_mean, 'center': curr_center, 'precision': curr_precision})
    return stacked_model

def stacked_mahalanobis_score_samples(stacked_model, feats_test):
    stacked_scores = np.zeros([feats_test.shape[0], len(stacked_model)])
    i = 0
    for model in stacked_model:
        curr_mean = model['mean']
        curr_center = model['center']
        curr_precision = model['precision']
        curr_feats = renormalize(feats_test, curr_mean) - curr_center
        curr_scores = -0.5*np.matmul(np.matmul(curr_feats, curr_precision), curr_feats.T).diagonal()
        stacked_scores[:, i] = curr_scores
        i += 1
    return stacked_scores

def run_onevsall_stacked_ocsvm_test(feats_tr, feats_ts, y_tr, y_ts, num_classes):
    all_means = get_means(feats_tr, y_tr)
    all_auroc = []
    all_auprc = []
    for i in range(num_classes):
        curr_feats_tr = feats_tr[y_tr==i]
        stacked_ocsvm = stacked_ocsvm_fit(curr_feats_tr, i, all_means)
        stacked_scores = stacked_ocsvm_score_samples(stacked_ocsvm, feats_ts)
        curr_scores = np.mean(stacked_scores, axis=1)
        curr_gt = np.zeros(y_ts.shape[0])
        curr_gt[y_ts==i] = 1
        auroc = roc_auc_score(curr_gt.astype(int), curr_scores)
        auprc = average_precision_score(curr_gt.astype(int), curr_scores)
        all_auroc.append(auroc)
        all_auprc.append(auprc)
        print("- %d: %.3f - %.3f" % (i, auroc, auprc))
    return np.asarray(all_auroc), np.asarray(all_auprc)


def run_onevsall_stacked_mahalanobis_test(feats_tr, feats_ts, y_tr, y_ts, num_classes):
    all_means = get_means(feats_tr, y_tr)
    all_auroc = []
    all_auprc = []
    for i in range(num_classes):
        curr_feats_tr = feats_tr[y_tr==i]
        stacked_mahalanobis = stacked_mahalanobis_fit(curr_feats_tr, i, all_means)
        stacked_scores = stacked_mahalanobis_score_samples(stacked_mahalanobis, feats_ts)
        curr_scores = np.mean(stacked_scores, axis=1)
        curr_gt = np.zeros(y_ts.shape[0])
        curr_gt[y_ts==i] = 1
        auroc = roc_auc_score(curr_gt.astype(int), curr_scores)
        auprc = average_precision_score(curr_gt.astype(int), curr_scores)
        all_auroc.append(auroc)
        all_auprc.append(auprc)
        print("- %d: %.3f - %.3f" % (i, auroc, auprc))
    return np.asarray(all_auroc), np.asarray(all_auprc)


def run_multiclass_ocsvm_test(feats_tr, feats_ts, y_tr, y_ts, num_classes):
    multiclass_scores = np.zeros([y_ts.shape[0], num_classes])
    multiclass_labels = np.zeros([y_ts.shape[0], num_classes])
    for i in range(num_classes):
        curr_feats_tr = feats_tr[y_tr==i]
        scaler = 1.0 / curr_feats_tr.shape[0]
        ocsvm = OneClassSVM(gamma='auto').fit(curr_feats_tr)
        curr_scores = ocsvm.score_samples(feats_ts) * scaler
        curr_gt = np.zeros(y_ts.shape[0])
        curr_gt[y_ts==i] = 1
        multiclass_scores[:, i] = curr_scores
        multiclass_labels[:, i] = curr_gt
    preds = np.argmax(multiclass_scores, axis=1)
    # precision = precision_score(y_ts.astype(int), preds, average='micro')
    # print("- Multiclass precision: %.3f" % (precision))
    precision = accuracy_score(y_ts.astype(int), preds)
    print("- Multiclass accuracy: %.3f" % precision)
    average_precisions = []
    for i in range(num_classes):
        curr_ap = average_precision_score(multiclass_labels[:, i].astype(int), multiclass_scores[:, i])
        average_precisions.append(curr_ap)   
    average_precisions = np.asarray(average_precisions)
    print("- Multiclass mAP: %.3f" % (np.mean(average_precisions)))
    return precision, average_precisions

def run_multiclass_mahalanobis_test_temp(feats_tr, feats_ts, y_tr, y_ts, num_classes):
    multiclass_scores = np.zeros([y_ts.shape[0], num_classes])
    multiclass_labels = np.zeros([y_ts.shape[0], num_classes])
    for i in range(num_classes):
        curr_feats_tr = feats_tr[y_tr==i].copy()
        scaler = 1.0 / (curr_feats_tr.shape[0] * curr_feats_tr.shape[0])
        curr_mean = np.mean(curr_feats_tr, axis=0)
        curr_feats_tr = curr_feats_tr - curr_mean
        group_lasso = EmpiricalCovariance(assume_centered=False).fit(curr_feats_tr)
        curr_precision = group_lasso.precision_
        curr_feats_ts = feats_ts.copy() - curr_mean
        curr_scores = -0.5 * np.matmul(np.matmul(curr_feats_ts, curr_precision), curr_feats_ts.T).diagonal()
        curr_gt = np.zeros(y_ts.shape[0])
        curr_gt[y_ts==i] = 1
        multiclass_scores[:, i] = curr_scores * scaler
        multiclass_labels[:, i] = curr_gt
    preds = np.argmax(multiclass_scores, axis=1)
    # precision = precision_score(y_ts.astype(int), preds, average='micro')
    # print("- Multiclass precision: %.3f" % (precision))
    precision = accuracy_score(y_ts.astype(int), preds)
    print("- Multiclass accuracy: %.3f" % precision)
    average_precisions = []
    for i in range(num_classes):
        curr_ap = average_precision_score(multiclass_labels[:, i].astype(int), multiclass_scores[:, i])
        average_precisions.append(curr_ap)    
    average_precisions = np.asarray(average_precisions)
    print("- Multiclass mAP: %.3f" % (np.mean(average_precisions)))
    return precision, average_precisions

def run_multiclass_mahalanobis_test(feats_tr, feats_ts, y_tr, y_ts, num_classes):
    multiclass_scores = np.zeros([y_ts.shape[0], num_classes])
    multiclass_labels = np.zeros([y_ts.shape[0], num_classes])
    for i in range(num_classes):
        curr_feats_tr = feats_tr[y_tr==i].copy()
        curr_mean = np.mean(curr_feats_tr, axis=0)
        curr_feats_tr = curr_feats_tr - curr_mean
        group_lasso = EmpiricalCovariance(assume_centered=False).fit(curr_feats_tr)
        curr_precision = group_lasso.precision_
        curr_feats_ts = feats_ts.copy() - curr_mean
        curr_scores = -0.5 * np.matmul(np.matmul(curr_feats_ts, curr_precision), curr_feats_ts.T).diagonal()
        curr_gt = np.zeros(y_ts.shape[0])
        curr_gt[y_ts==i] = 1
        multiclass_scores[:, i] = curr_scores
        multiclass_labels[:, i] = curr_gt
    preds = np.argmax(multiclass_scores, axis=1)
    # precision = precision_score(y_ts.astype(int), preds, average='micro')
    # print("- Multiclass precision: %.3f" % (precision))
    precision = accuracy_score(y_ts.astype(int), preds)
    print("- Multiclass accuracy: %.3f" % precision)
    average_precisions = []
    for i in range(num_classes):
        curr_ap = average_precision_score(multiclass_labels[:, i].astype(int), multiclass_scores[:, i])
        average_precisions.append(curr_ap)    
    average_precisions = np.asarray(average_precisions)
    print("- Multiclass mAP: %.3f" % (np.mean(average_precisions)))
    return precision, average_precisions

def run_multiclass_stacked_ocsvm_test(feats_tr, feats_ts, y_tr, y_ts, num_classes):
    all_means = get_means(feats_tr, y_tr)
    multiclass_scores = np.zeros([y_ts.shape[0], num_classes])
    multiclass_labels = np.zeros([y_ts.shape[0], num_classes])
    for i in range(num_classes):
        curr_feats_tr = feats_tr[y_tr==i]
        scaler = 1.0 / curr_feats_tr.shape[0]
        stacked_ocsvm = stacked_ocsvm_fit(curr_feats_tr, i, all_means)
        stacked_scores = stacked_ocsvm_score_samples(stacked_ocsvm, feats_ts)
        curr_scores = np.mean(stacked_scores, axis=1) * scaler
        curr_gt = np.zeros(y_ts.shape[0])
        curr_gt[y_ts==i] = 1
        multiclass_scores[:, i] = curr_scores
        multiclass_labels[:, i] = curr_gt
    preds = np.argmax(multiclass_scores, axis=1)
    # precision = precision_score(y_ts.astype(int), preds, average='micro')
    # print("- Multiclass precision: %.3f" % (precision))
    precision = accuracy_score(y_ts.astype(int), preds)
    print("- Multiclass accuracy: %.3f" % precision)
    average_precisions = []
    for i in range(num_classes):
        curr_ap = average_precision_score(multiclass_labels[:, i].astype(int), multiclass_scores[:, i])
        average_precisions.append(curr_ap) 
    average_precisions = np.asarray(average_precisions)
    print("- Multiclass mAP: %.3f" % (np.mean(average_precisions)))
    return precision, average_precisions

def run_multiclass_stacked_mahalanobis_test(feats_tr, feats_ts, y_tr, y_ts, num_classes):
    all_means = get_means(feats_tr, y_tr)
    multiclass_scores = np.zeros([y_ts.shape[0], num_classes])
    multiclass_labels = np.zeros([y_ts.shape[0], num_classes])
    for i in range(num_classes):
        curr_feats_tr = feats_tr[y_tr==i]
        stacked_mahalanobis = stacked_mahalanobis_fit(curr_feats_tr, i, all_means)
        stacked_scores = stacked_mahalanobis_score_samples(stacked_mahalanobis, feats_ts)
        curr_scores = np.mean(stacked_scores, axis=1)
        curr_gt = np.zeros(y_ts.shape[0])
        curr_gt[y_ts==i] = 1
        multiclass_scores[:, i] = curr_scores
        multiclass_labels[:, i] = curr_gt
    preds = np.argmax(multiclass_scores, axis=1)
    # precision = precision_score(y_ts.astype(int), preds, average='micro')
    # print("- Multiclass precision: %.3f" % (precision))
    precision = accuracy_score(y_ts.astype(int), preds)
    print("- Multiclass accuracy: %.3f" % precision)
    average_precisions = []
    for i in range(num_classes):
        curr_ap = average_precision_score(multiclass_labels[:, i].astype(int), multiclass_scores[:, i])
        average_precisions.append(curr_ap)
    
    average_precisions = np.asarray(average_precisions)
    print("- Multiclass mAP: %.3f" % (np.mean(average_precisions)))
    return precision, average_precisions

def run_multiclass_stacked_mahalanobis_test_temp(feats_tr, feats_ts, y_tr, y_ts, num_classes):
    all_means = get_means(feats_tr, y_tr)
    multiclass_scores = np.zeros([y_ts.shape[0], num_classes])
    multiclass_labels = np.zeros([y_ts.shape[0], num_classes])
    for i in range(num_classes):
        curr_feats_tr = feats_tr[y_tr==i]
        scaler = 1.0 / (curr_feats_tr.shape[0] * curr_feats_tr.shape[0])
        stacked_mahalanobis = stacked_mahalanobis_fit(curr_feats_tr, i, all_means)
        stacked_scores = stacked_mahalanobis_score_samples(stacked_mahalanobis, feats_ts)
        curr_scores = np.mean(stacked_scores, axis=1)
        curr_gt = np.zeros(y_ts.shape[0])
        curr_gt[y_ts==i] = 1
        multiclass_scores[:, i] = curr_scores * scaler
        multiclass_labels[:, i] = curr_gt
    preds = np.argmax(multiclass_scores, axis=1)
    # precision = precision_score(y_ts.astype(int), preds, average='micro')
    # print("- Multiclass precision: %.3f" % (precision))
    precision = accuracy_score(y_ts.astype(int), preds)
    print("- Multiclass accuracy: %.3f" % precision)
    average_precisions = []
    for i in range(num_classes):
        curr_ap = average_precision_score(multiclass_labels[:, i].astype(int), multiclass_scores[:, i])
        average_precisions.append(curr_ap)
    
    average_precisions = np.asarray(average_precisions)
    print("- Multiclass mAP: %.3f" % (np.mean(average_precisions)))
    return precision, average_precisions

def run_multiclass_linearSVM_test(feats_tr, feats_ts, y_tr, y_ts, num_classes):
    model = LinearSVC().fit(feats_tr, y_tr)
    preds = model.predict(feats_ts)
    # precision = precision_score(y_ts.astype(int), preds, average='micro')
    # print("- Multiclass precision: %.3f" % (precision))
    precision = accuracy_score(y_ts.astype(int), preds)
    print("- Multiclass accuracy: %.3f" % precision)
    multiclass_scores = model.decision_function(feats_ts)
    if num_classes == 2:
        ap = average_precision_score(y_ts.astype(int), multiclass_scores)
        average_precisions = [ap]
    else:
        average_precisions = []
        for i in range(num_classes):
            curr_gt = np.zeros(y_ts.shape[0])
            curr_gt[y_ts==i] = 1
            curr_ap = average_precision_score(curr_gt.astype(int), multiclass_scores[:, i])
            average_precisions.append(curr_ap)
    average_precisions = np.asarray(average_precisions)
    print("- Multiclass mAP: %.3f" % (np.mean(average_precisions)))
    return precision, average_precisions

def run_multiclass_SVM_test(feats_tr, feats_ts, y_tr, y_ts, num_classes, kernel='rbf'):
    model = SVC(kernel=kernel).fit(feats_tr, y_tr)
    preds = model.predict(feats_ts)
    # precision = precision_score(y_ts.astype(int), preds, average='micro')
    # print("- Multiclass precision: %.3f" % (precision))
    precision = accuracy_score(y_ts.astype(int), preds)
    print("- Multiclass accuracy: %.3f" % precision)
    multiclass_scores = model.decision_function(feats_ts)
    if num_classes == 2:
        ap = average_precision_score(y_ts.astype(int), multiclass_scores)
        average_precisions = [ap]
    else:
        average_precisions = []
        for i in range(num_classes):
            curr_gt = np.zeros(y_ts.shape[0])
            curr_gt[y_ts==i] = 1
            curr_ap = average_precision_score(curr_gt.astype(int), multiclass_scores[:, i])
            average_precisions.append(curr_ap)
    average_precisions = np.asarray(average_precisions)
    print("- Multiclass mAP: %.3f" % (np.mean(average_precisions)))
    return precision, average_precisions